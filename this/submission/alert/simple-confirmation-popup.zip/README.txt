A Pen created at CodePen.io. You can find this one at https://codepen.io/adventuresinmissions/pen/nrhHF.

 Simple responsive confirmation dialog box, with a subtle CSS3 entry animation. http://codyhouse.co/gem/simple-confirmation-popup/